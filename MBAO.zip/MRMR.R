#___________________________________________________________________  %
#  Mutation-based Binary Aquila optimizer source code                 %
#                                                                     %
#  Developed in R programming Language                                %
#                                                                     %
#  Author and programmer: Elham Pashaei                               %
#                                                                     %
#         e-Mail: elham.pashaei@gmail.com                             %
#                 epashaei@gelisim.edu.tr                             %
#                                                                     %               
#                                                                     %
#   Main paper: Elham Pashaei, Mutation-based Binary Aquila optimizer %
#               for gene selection in cancer classification,          %
#               Computational Biology and Chemistry ,2022             %
#                                                                     %
#______________________________________________________________ _____ %

# This function pre-filter the data sets using MRMR filtering approach

mrmr <- function(data) {
  
  rm(list = ls())
  library(foreign)      # load library
  library(farff)
  library("praznik")
  
  nF=100                #Determine the number of selected Top ranked genes

  data <- read.arff(x)  # read dataset
  #data <- read.csv(x)  # to read .csv file format datasets
  
  dim(data)
  str(data)   # provide information on data
  
  nn <- colnames(data)
  mm <- paste0("f", 1:(ncol(data) - 1))
  colnames(data) <- c(mm, "class")        # label features
   
  class <- data[, ncol(data)]
  cc <- levels(class)
  
  #..........................................................
  #Normalize data
  data <- data[, -ncol(data)]
  normalize <- function(x) {
    return ((x - min(x)) / (max(x) - min(x)))
  }
  maxmindf <- as.data.frame(lapply(data, normalize))
  data <- maxmindf
  data$class <- class
  
  #..........................................................
  r <- MRMR(data[, -ncol(data)], class, nF) #perform MRMR filtering approach
  index <- r$selection
  fdata <- data[, index]
  fdata$class <- class
  
  return (fdata) 
  #write.arff(fdata, "FilterData.arff") # provide reduced data set
}
