rm(list = ls())
library(foreign)
library(farff)
library("praznik")

#choose the number of selected feature
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#load dataset
x <- choose.files()
#x <-"C:\\Users\\elham\\Downloads\\CNS.arff"
data <- read.arff(x)
dim(data)
str(data)

nn <- colnames(data)
mm <- paste0("f",1:(ncol(data)-1))
colnames(data) <- c(mm,"class")

class <- data[,ncol(data)]
lable <- data[,ncol(data)]
cc <- levels(class)

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#Normalize 
data <- data[,-ncol(data)]
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}
maxmindf <- as.data.frame(lapply(data, normalize))
data <- maxmindf
data$class <- class

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
r <- MRMR(data[,-ncol(data)],class,100) 
#r <- MIM(data[,-ncol(data)],class,50)
index<- r$selection
fdata <- data[,index]
#ss <- nn[index]
#colnames(fdata) <- ss
fdata$class <- class


setwd("C:/Users/elham/Downloads")
#write.csv(fdata, "Colony100mrmr.csv")
write.arff(fdata,"CNS100mrmr.arff")
