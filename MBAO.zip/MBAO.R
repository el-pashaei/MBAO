rm(list=ls())
library(caret)
library('randomForest')
library(FSelector)
library(foreign)
library(plyr)
library(class)
library(e1071)
library(pracma)

ptm <- proc.time()
set.seed(3)
#source("C:\\Users\\elham\\Documents\\R\\Eagle\\fitness1.R")
#source("/Users/epashaei/Documents/R/R-3.6.1/bin/CrossoverX.R")
#source("/Users/epashaei/Documents/R/R-3.6.1/bin/dtree5_repeatedcv.R")

#==================================================================================
#load dataset after applying mRMR filtering method 
#x <- choose.files()
x <- "/Users/epashaei/Documents/R/R-3.6.1/bin/MRMR-Ovarian100.arff"
data <- read.arff(x)
data <- data.frame(data,check.names = TRUE)

dim(data)
iden <- names(data)
rownames(data)
iden[ncol(data)]
class <- data[,ncol(data)]
levels(class)
col= (ncol(data)-1)
Dim=col
#==================================================================================
#===================================================================================
fitness <- function(star) {
  #star <- my.stars[2,]
  #cat("dim:",dim(star))
  index <- which(star == 1)
  ## In case no predictors are selected:
  if (length(index) == 0 | length(index) == 1 ){
    return(0)
  }
  subData <- data[,index]
  dimo <- dim(subData)
  subData$class <- data$class
  #----------------------------------
  #SETTING k-fold or LOOV
  type <-"k-fold"
  kf=10
  if(type=="k-fold"){
    a <- createFolds(subData$class,k=kf, list=FALSE)
    subData$id <-a
    t=kf;
  }else{
    t <-nrow(subData)
    subData$id <- 1:t
  }
  #---------------------------------
  score = list()
  #cat("salam",'\n')
  for(i in 1:t){
    
    train1 <- subData[subData$id != i, -ncol(subData)]# delete id
    test1 <-  subData[subData$id == i, -ncol(subData)]#
    test_lable <- test1$class
    test2 <- test1[,-ncol(test1)]
    
    #model <- randomForest(class ~., data=train1) 
    model = svm(class ~ .,data = train1,  type = 'C-classification',kernel = "linear")
    #    scale = FALSE)#, gamma =0.001, cost = 1, degree=2)
    
    pred <-predict(model, test2)
    accuracy <- mean(pred == test_lable)*100
    score[[i]] = accuracy # score/error of ith fold
    
  }
  out <- round( mean(unlist(score)), digits = 2)
  #out1 <- out+ 0.001*(1/length(index))
  #out1 <- (0.8*out) +(0.2*((col-length(index))/col))
  return(out)
}
#=================================================================================
############==================# Initialization #=======================###########
M_Iter = 50         # Maximum number of iteration
swarm_size =N = 35  # population size
r=round(runif(1),6)    #uniformly distributed random numbers[0,1] 
PP=pi;

bs=rep(0,M_Iter) # (fitness values)
bsg=rep(0,M_Iter) # (fitness values)

population <- matrix(data = sample(0:1, size = swarm_size * col, replace = TRUE),
                     nrow = swarm_size,ncol = col) # initialize population(stars)
X <- data.frame(population) 

Best_P=rep(0,col)
Best_FF=0
p1=rep(0,col)
p2=rep(0,col)

Xnew=X
Ffun=rep(0,swarm_size)     # (fitness values)
Ffun_new=rep(0,swarm_size) # (fitness values)
bs=rep(0,M_Iter)           # (fitness values)

t=1;
alpha=0.1;
delta=0.1;

T0=0.1;       # Initial Temp.
# Intialize Temp.
TT=T0;
mu=0.02;       # Mutation Rate 0.1-1

#==============================================================================
nfeature<- function(vec){
  #vec <- my.stars[i,]
  vec <- as.numeric(vec)
  a<- table(vec)
  out <- a[names(a)==1]
  if(length(out)==0){
    out=0
  }
  return(out)
}
#================================================================================

Levy <- function(d)
{  
  beta=1.5
  sigma=(gamma(1+beta)*sin(PP*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta)
  u=rnorm(d)*sigma
  v=rnorm(d)
  step=u/abs(v)^(1/beta)
  o=step
  return(o)
}

#==============================================================================
mutation <- function(x)
{
  nVar=ncol(x)
  nmu=ceil(mu*nVar)
  j=sample(1:nVar, size = nmu)
  y=x
  y[j]=1-x[j]
  
  return(y)
  
}

############=====================# Algorithm #========================###########
#BEST solution initialization

for(i in 1:swarm_size){
  Ffun[i] <- fitness(X[i,]) #Evaluate fitness of solution
}                                             
bestindex=which.max(Ffun)                       
Best_P = X[bestindex, ]                      
Best_FF= max(Ffun)   
cat("best:",Best_FF,"Number of feature:",sum(Best_P),'\n')
#================================================================================
while (t <= M_Iter){
  bs[t]=Best_FF;
  bsg[t]=nfeature(Best_P);
  #mu=runif(1, min=0.1, max=0.9);
  for(i in 1:swarm_size){ 
    G1=(2*round(runif(1),6))-1    
    G2=2*(1-(t/M_Iter))          
    to = 1:Dim
    u = 0.0265
    r0 = 10
    r = r0 +u *to
    omega = 0.005
    phi0 = 3*PP/2
    phi = -omega*to+phi0
    x = r * sin(phi)    
    y = r * cos(phi)    
    r2=round(runif(1),6)
    QF=t^((2*r2-1)/(1-M_Iter)^2)     # Eq. (9)
    MM=mean(as.numeric(X[i,]))
    
    r2=round(runif(1),4)
    r3=round(runif(1),4)
    r4=round(runif(1),4)
    r5=round(runif(1),4)
    r6=round(runif(1),4)
    
    if (t<=(2/3)*M_Iter){
      if( r2 > 0.5)
      {
        Xnew[i,]=Best_P[1,]*(1-t/M_Iter)+(MM- Best_P[1,]* r3)
      }else{
        ino <-sample(1:N,1)
        Xnew[i,]=Best_P[1,]* Levy(Dim)+(X[ino,])+(y-x)*r4
      }  
    }else{
      if( r4 > 0.5)
      {  VV=sample(0:1, size =N, replace = TRUE)
         Xnew[i,]=(Best_P[1,]-MM)*alpha-r5+VV*delta 
      }else{
        Xnew[i,]=QF*Best_P[1,]-(G1*X[i,]*r5)-G2*Levy(Dim)+ r6*G1 }  
    }
   
    rrr=round(runif(1),4)
    omin=1;omax=10
    eo=(omin-omax)*(t/M_Iter)+omin
    for(j in 1:col){
      #soo=abs(tanh(ee*Xnew[i,j]))
      #soo=abs(Xnew[i,j])/ sqrt(1+(Xnew[i,j]^2))
      #soo=1/(1+exp(-Xnew[i,j]))
      soo1=1/(1+exp(eo*-Xnew[i,j]))      #Eq. (12)
      soo2=1/(1+exp(eo*Xnew[i,j]))       #Eq. (13)
      if( soo1 > round(runif(1),4)) {
        #Xnew[i,j]=1
        p1[j]=1
      }else{
        #Xnew[i,j]=0
        p1[j]=0
      }
      if( soo2 < round(runif(1),4)) {
        #Xnew[i,j]=1
        p2[j]=1
      }else{
        #Xnew[i,j]=0
        p2[j]=0
      }
      
    }
    f1=fitness(p1)
    f2=fitness(p2)
    if(f1>f2)
    {
      Xnew[i,]=p1
    }else{
      Xnew[i,]=p2
    }
    
    Ffun_new[i] <- fitness(Xnew[i,]) #Evaluate fitness of solution
    if( Ffun_new[i] > Ffun[i]) { 
      X[i,]=Xnew[i,]
      Ffun[i]=Ffun_new[i]
    }else if((Ffun_new[i] == Ffun[i]) && nfeature(Xnew[i,])< nfeature(X[i,])){
      X[i,]=Xnew[i,]
      Ffun[i]=Ffun_new[i]
    }
    
    if(Ffun[i] > Best_FF && nfeature(X[i,])<= nfeature(Best_P)) {
      Best_FF=Ffun[i]
      Best_P=X[i,]
    }else if(Ffun[i] == Best_FF && nfeature(X[i,])< nfeature(Best_P)){
      Best_FF=Ffun[i]
      Best_P=X[i,]
    }
    
    #cat("GOL\n")
    #=====================================================================
    #mutation
    solo=mutation(X[i,])
    fsolo=fitness(solo)
    if((fsolo > Best_FF && nfeature(solo)<= nfeature(Best_P))
       || ((fsolo== Best_FF && nfeature(solo)< nfeature(Best_P))) )
      #if(fsolo > Best_FF)
    {
      Best_FF=fsolo
      Best_P=solo
      
      X[i,]=solo
      Ffun[i]=fsolo}
    
  }
  #end for  
  
  cat("iteration",t,"best:",Best_FF,"Number of feature:",sum(Best_P),'\n')
  t=t+1
  
} # end of iteration

#fitness1(Best_P)
e=proc.time() - ptm
cputime=0
cputime=e[1]+e[2]
print(Best_P)
q1 = which(Best_P>0)
print(q1)
print(cputime)
print(length(q1))
xx=0;xx=Best_P;
s=matrix(0,nrow=1,ncol=10)
if (TRUE){
  for (j in 1:10) {
    s[1,j]=fitness(xx)
    
  }
}
print(mean(s))











