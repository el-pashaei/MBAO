#___________________________________________________________________  %
#  Mutation-based Binary Aquila optimizer source code                 %
#                                                                     %
#  Developed in R programming Language                                %
#                                                                     %
#  Author and programmer: Elham Pashaei                               %
#                                                                     %
#         e-Mail: elham.pashaei@gmail.com                             %
#                 epashaei@gelisim.edu.tr                             %
#                                                                     %               
#                                                                     %
#   Main paper: Elham Pashaei, Mutation-based Binary Aquila optimizer %
#               for gene selection in cancer classification,          %
#               Computational Biology and Chemistry ,2022             %
#                                                                     %
#______________________________________________________________ _____ %

# This function selected best subset of features using proposed MBAO

MBAO <- function (data, M_Iter , N, mu) {
  #rm(list=ls())
  #Load packages
  library(caret)
  library('randomForest')
  library(FSelector)
  library(foreign)
  library(plyr)
  library(class)
  library(e1071)
  library(pracma)
  set.seed(3)
  
  class <- data[, ncol(data)]
  col = (ncol(data) - 1)
  Dim = col   # Dimension Number
  #====================================================================
  ############==============# fitness function #============###########
  
  # fitness function for evaluating each solution
  fitness <- function(star) {         
    index <- which(star == 1)
    ## In case no predictors are selected:
    if (length(index) == 0 | length(index) == 1) {
      return(0)
    }
    subData <- data[, index]
    dimo <- dim(subData)
    subData$class <- data$class
    #SETTING k-fold or LOOV cross validation
    type <- "k-fold"
    kf = 10
    if (type == "k-fold") {
      a <- createFolds(subData$class, k = kf, list = FALSE)
      subData$id <- a
      t = kf
      
    } else{
      t <- nrow(subData)
      subData$id <- 1:t
    }
    score = list()
    for (i in 1:t) {
      train1 <- subData[subData$id != i,-ncol(subData)]# delete id
      test1 <-  subData[subData$id == i,-ncol(subData)]#
      test_lable <- test1$class
      test2 <- test1[, -ncol(test1)]
      #perform classification and prediction using SVM classifier
      model = svm(class ~ .,data = train1,type = 'C-classification', kernel = "linear") 
      pred <- predict(model, test2)
      accuracy <- mean(pred == test_lable) * 100
      score[[i]] = accuracy 
      
    }
    out <- round(mean(unlist(score)), digits = 2)
    #out1 <- out+ 0.001*(1/length(index))
    #out1 <- (0.8*out) +(0.2*((col-length(index))/col))
    return(out)
  }
  #===================================================================
  ###########============# Initialization #===============###########
  swarm_size = N   # population size
  PP = pi 
  alpha = 0.1
  delta = 0.1
  t = 1  
  
  p1 = rep(0, col)
  p2 = rep(0, col)
  
  Ffun = rep(0, swarm_size)      # initial fitness values
  Ffun_new = rep(0, swarm_size)  # initial fitness values
  bs = rep(0, M_Iter)            # initial fitness values
  bsg = rep(0, M_Iter)           # initial fitness values
  Best_P = rep(0, col)           # location of best solution
  Best_FF = 0                    # fitness of best solution

  # initialize population(Aquila)
  population <- matrix(data = sample(0:1, size = swarm_size * col, replace = TRUE),
      nrow = swarm_size,ncol = col)                 
  X <- data.frame(population)
  Xnew = X
  #===================================================================
  ############===========# number of features #===========############
  #calculate number of selected feature for each candidate solution
  nfeature <- function(vec) {
    vec <- as.numeric(vec)
    a <- table(vec)
    out <- a[names(a) == 1]
    if (length(out) == 0) {
      out = 0
    }
    return(out)
  }
 
  #===================================================================
  ############=======# Levy flight distribution #========############  
  Levy <- function(d)  #Eq. (5)
  {
    beta = 1.5
    sigma = (gamma(1 + beta) * sin(PP * beta / 2) / (gamma((1 + beta) / 2) *
                                                       beta * 2 ^ ((beta - 1) / 2))) ^ (1 / beta)
    u = rnorm(d) * sigma
    v = rnorm(d)
    step = u / abs(v) ^ (1 / beta)
    o = step
    return(o)
  }
  
  #===================================================================
  ############==========# mutation operator #============############  
  mutation <- function(x)
  {
    nVar = ncol(x)
    nmu = ceil(mu * nVar)
    j = sample(1:nVar, size = nmu)
    y = x
    y[j] = 1 - x[j]
    
    return(y)
    
  }

  #===================================================================
  ##########==========# Binary Aquila optimizer #============########  
  #BEST solution initialization
  
  for (i in 1:swarm_size) {
    Ffun[i] <- fitness(X[i, ]) #Evaluate fitness of each solution
  }
  bestindex = which.max(Ffun)
  Best_P = X[bestindex,]
  Best_FF = max(Ffun)
  #cat("best:", Best_FF, "Number of feature:", sum(Best_P), '\n')
 
  
  while (t <= M_Iter) {
    bs[t] = Best_FF
    
    bsg[t] = nfeature(Best_P)
    # instead of using a fix value, we can adjust mu's value randomly.
    # mu=runif(1, min=0.01, max=0.9); 
    for (i in 1:swarm_size) {
      G1 = (2 * round(runif(1), 6)) - 1
      G2 = 2 * (1 - (t / M_Iter))
      to = 1:Dim
      u = 0.0265
      r0 = 10
      r = r0 + u * to   # Eq. (6)
      omega = 0.005
      phi0 = 3 * PP / 2
      phi = -omega * to + phi0  # Eq. (6)
      x = r * sin(phi)
      y = r * cos(phi)
      r2 = round(runif(1), 6)
      QF = t ^ ((2 * r2 - 1) / (1 - M_Iter) ^ 2)     # Eq. (9)
      MM = mean(as.numeric(X[i, ]))  # Eq. (3)
      
      r2 = round(runif(1), 4)
      r3 = round(runif(1), 4)
      r4 = round(runif(1), 4)
      r5 = round(runif(1), 4)
      r6 = round(runif(1), 4)
      
      if (t <= (2 / 3) * M_Iter) {
        if (r2 > 0.5)
        {
          Xnew[i, ] = Best_P[1, ] * (1 - t / M_Iter) + (MM - Best_P[1, ] * r3)  # Eq. (2)
        } else{
          ino <- sample(1:N, 1)
          Xnew[i, ] = Best_P[1, ] * Levy(Dim) + (X[ino, ]) + (y - x) * r4  # Eq. (4)
        }
      } else{
        if (r4 > 0.5)
        {
          VV = sample(0:1, size = N, replace = TRUE)
          Xnew[i, ] = (Best_P[1, ] - MM) * alpha - r5 + VV * delta  # Eq. (7)
        } else{
          Xnew[i, ] = QF * Best_P[1, ] - (G1 * X[i, ] * r5) - G2 * Levy(Dim) + r6 * G1 # Eq. (8)
        }
      }
      
      rrr = round(runif(1), 4)
      omin = 1
      omax = 10
      eo = (omin - omax) * (t / M_Iter) + omin  # Eq. (14)
      for (j in 1:col) {
        soo1 = 1 / (1 + exp(eo * -Xnew[i, j]))      #Eq. (12)
        soo2 = 1 / (1 + exp(eo * Xnew[i, j]))       #Eq. (13)
        if (soo1 > round(runif(1), 4)) {
           p1[j] = 1
        } else{
           p1[j] = 0
        }
        if (soo2 < round(runif(1), 4)) {
          p2[j] = 1
        } else{
          p2[j] = 0
        }
        
      }
      f1 = fitness(p1)
      f2 = fitness(p2)
      if (f1 > f2)
      {
        Xnew[i, ] = p1
      } else{
        Xnew[i, ] = p2
      }
      
      #Update current and Best solution
      Ffun_new[i] <- fitness(Xnew[i, ]) #Evaluate fitness of solution
      if (Ffun_new[i] > Ffun[i]) {
        X[i, ] = Xnew[i, ]
        Ffun[i] = Ffun_new[i]
      } else if ((Ffun_new[i] == Ffun[i]) &&
                 nfeature(Xnew[i, ]) < nfeature(X[i, ])) {
        X[i, ] = Xnew[i, ]
        Ffun[i] = Ffun_new[i]
      }
      
      if (Ffun[i] > Best_FF && nfeature(X[i, ]) <= nfeature(Best_P)) {
        Best_FF = Ffun[i]
        Best_P = X[i, ]
      } else if (Ffun[i] == Best_FF &&
                 nfeature(X[i, ]) < nfeature(Best_P)) {
        Best_FF = Ffun[i]
        Best_P = X[i, ]
      }
      
      #=====================================================================
      #perform mutation
      solo = mutation(X[i, ])
      fsolo = fitness(solo)
      if ((fsolo > Best_FF && nfeature(solo) <= nfeature(Best_P))
          || ((fsolo == Best_FF && nfeature(solo) < nfeature(Best_P))))
      {
        Best_FF = fsolo
        Best_P = solo
        
        X[i, ] = solo
        Ffun[i] = fsolo
      }
      
    }
    #end for
    
    cat("iteration",t, "best:", Best_FF,"Number of feature:",sum(Best_P),'\n')
    t = t + 1
    
  } # end of iteration
  
  #fitness1(Best_P)
  #print(Best_P)
  q1 = which(Best_P > 0)
  #print(q1)              #index of selected features 
  #print(length(q1))      #number of selected features
  NumberofFeature=length(q1)
  xx = 0
  xx = Best_P
  
  s = matrix(0, nrow = 1, ncol = 10)
  if (TRUE) {
    for (j in 1:10) {
      s[1, j] = fitness(xx)
      
    }
  }
  averageACC=max(s)
  #print(averageACC)
  return(c(NumberofFeature,averageACC, q1))
  
}










