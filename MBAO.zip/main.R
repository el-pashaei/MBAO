#___________________________________________________________________  %
#  Mutation-based Binary Aquila optimizer source code                 %
#                                                                     %
#  Developed in R programming Language                                %
#                                                                     %
#  Author and programmer: Elham Pashaei                               %
#                                                                     %
#         e-Mail: elham.pashaei@gmail.com                             %
#                 epashaei@gelisim.edu.tr                             %
#                                                                     %               
#                                                                     %
#   Main paper: Elham Pashaei, Mutation-based Binary Aquila optimizer %
#               for gene selection in cancer classification,          %
#               Computational Biology and Chemistry ,2022             %
#                                                                     %
#______________________________________________________________ _____ %


rm(list = ls())
getwd()                             # get working directory
setwd("C:/Users/elham/Downloads")   # set your main working directory. You can set it to any path
source("MRMR.R")                    # you should put data sets,and codes in your main working directory
source("MBAO.R")



M_Iter = 25                    # Maximum number of iteration
N = 35                         # population size
mu = 0.05                      # Mutation Rate [0.01,0.9]
                               #for better performance, mutation rate can adjusted by tuning. 

x <- choose.files()                      #load a microarray data set; for example colon.arff         
data <- mrmr(x)                          #perform MRMR filtering approach
output <- MBAO (data, M_Iter , N, mu)    #perform MBAO algorithm

cat("Number of selected features is: ",output[1])
cat("The Best Accuracy is:", output[2])
cat("Index of selected features are:", output[c(3:length(output))])





